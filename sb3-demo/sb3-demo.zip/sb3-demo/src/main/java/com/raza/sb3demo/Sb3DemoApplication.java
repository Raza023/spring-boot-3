package com.raza.sb3demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb3DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb3DemoApplication.class, args);
	}

}
