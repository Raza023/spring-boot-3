package com.raza.sb3client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb3ClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb3ClientApplication.class, args);
	}

}
